# Data
objFile = None  # File Handle


class ProductData:
    """ Class to read and write product data """
    # Processing
    @staticmethod
    def write_product_user_input(file):
        """ Ask for product data and write to provided file """
        try:
            print("Type in a Product Id, Name, and Price you want to add to the file")
            print("(Enter 'Exit' to quit!)")
            while True:
                str_user_input = input("Enter the Id, Name, and Price (ex. 1,ProductA,9.99): ")
                if str_user_input.lower() == "exit": break
                else: file.write(str_user_input + "\n")
        except Exception as e:
            print("Error: " + str(e))

    @staticmethod
    def read_all_file_data(file, message="Contents of File"):
        """ Write to a provided file and print a provided message to user """
        try:
            print(message)
            file.seek(0)
            print(file.read())
        except Exception as e:
            print("Error: " + str(e))


# I/O
try:  # Body of the code that opens a file and then interacts with the ProductData class
    objFile = open("Products.txt", "r+")
    ProductData.read_all_file_data(objFile, "Here is the current data:")
    ProductData.write_product_user_input(objFile)
    ProductData.read_all_file_data(objFile, "Here is the data that was saved:")
except FileNotFoundError as e:
    print("Error: " + str(e) + "\n Please check the file name")
except Exception as e:
    print("Error: " + str(e))
finally:
    if objFile is not None: objFile.close()

