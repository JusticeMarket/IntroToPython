import pickle

FileName="todo.dat"   #Our text file name

fh=open(FileName, "wb")
dicrow1={"Task":"Clean House","Priority":"low"}
dicrow2={"Task":"Pay Bills","Priority":"high"}
pickle.dump(dicrow1,fh)
pickle.dump(dicrow2,fh)
fh.close()

fh=open(FileName,"rb")
line = pickle.load(fh)
while(True):
    try:
        print(line["Task"],",",line["Priority"])
        line = pickle.load(fh)
    except EOFError:
        break


