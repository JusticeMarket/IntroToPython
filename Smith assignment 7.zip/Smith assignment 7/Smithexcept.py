
fake = "C:\\Desktop\\fakefakefakefake.txt"  # File that doesn't exist
file = None
listOfLines = []  # List that would be added to if file existed

try:
    file = open(fake, "r")  # Try to open the fake 
except IOError:
    print("That doesn't exist")
except Exception as e:  
    print("There was an issue opening ", fake)
    print("Python error: ", e)

# If the file existed then theFile would not be None and processing could occur
if file is not None:
    for line in file.readlines():
        listOfLines.append(line)
else:
    print("The file couldn't be read")
